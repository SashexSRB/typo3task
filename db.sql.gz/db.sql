-- MySQL dump 10.13  Distrib 8.4.3, for Linux (x86_64)
--
-- Host: db    Database: db
-- ------------------------------------------------------
-- Server version	8.4.5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `config` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `icon` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `cruser_id` int unsigned NOT NULL DEFAULT '0',
  `widgets` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `identifier` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES (1,0,1748596227,1748596227,0,0,0,0,2,'{\"be3ab3b30a6111f5e212184e64bd2af28b97b968\":{\"identifier\":\"t3information\"},\"4fd2e1f5911ce17c0fab5563b0dee87c85291bb1\":{\"identifier\":\"docGettingStarted\"},\"a38b29d9fa3e359f7b3bc1d4b10912edcfd0e6d3\":{\"identifier\":\"t3news\"}}','66552f04f580dafb9440279c195cafebac246cb7','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `tables_select` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `title` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `db_mountpoints` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `file_mountpoints` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `file_permissions` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `workspace_perms` smallint unsigned NOT NULL DEFAULT '0',
  `pagetypes_select` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `tables_modify` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `non_exclude_fields` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `explicit_allowdeny` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `allowed_languages` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `custom_options` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `groupMods` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `mfa_providers` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `TSconfig` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `subgroup` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `category_perms` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `availableWidgets` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ses_userid` int unsigned NOT NULL DEFAULT '0',
  `ses_tstamp` int unsigned NOT NULL DEFAULT '0',
  `ses_data` longblob DEFAULT (NULL),
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES ('4b3983b11bd03cffe867c82d9abcf045bc157213aac7f85a1d8854b334b82386','[DISABLED]',2,1749213129,_binary 'a:3:{s:26:\"formProtectionSessionToken\";s:64:\"a746ef2036bb33bc2c55c0153370ecbc4ec17e349c45e88873dec3de3fa54493\";s:23:\"backend.sudo-mode.claim\";s:2:\"[]\";s:23:\"backend.sudo-mode.grant\";s:290:\"{\"route:\\/module\\/tools\\/maintenance\":{\"subject\":{\"class\":\"TYPO3\\\\CMS\\\\Backend\\\\Security\\\\SudoMode\\\\Access\\\\RouteAccessSubject\",\"identity\":\"route:\\/module\\/tools\\/maintenance\",\"subject\":\"\\/module\\/tools\\/maintenance\",\"lifetime\":\"medium\",\"group\":\"systemMaintainer\"},\"expiration\":1749213521}}\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `disable` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `lang` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT (NULL),
  `workspace_id` int NOT NULL DEFAULT '0',
  `mfa` mediumblob DEFAULT (NULL),
  `password_reset_token` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `usergroup` varchar(512) COLLATE utf8mb4_general_ci DEFAULT '',
  `avatar` int unsigned NOT NULL DEFAULT '0',
  `db_mountpoints` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `file_mountpoints` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `realName` varchar(80) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `admin` smallint unsigned NOT NULL DEFAULT '0',
  `options` smallint unsigned NOT NULL DEFAULT '3',
  `file_permissions` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `workspace_perms` smallint unsigned NOT NULL DEFAULT '1',
  `userMods` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `allowed_languages` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `TSconfig` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `lastlogin` bigint NOT NULL DEFAULT '0',
  `category_perms` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES (1,0,1748595961,1748595961,0,0,0,0,NULL,'default',_binary 'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$d3FEelN5VWpRV2kyWHp3WQ$on/Yh7qmtbhLKoGbQgJPMnF7fM368DnxI9OyADqEea0','',0,NULL,'','','',1,3,NULL,1,NULL,'',NULL,0,NULL),(2,0,1749202448,1748596201,0,0,0,0,NULL,'default',_binary 'a:22:{s:10:\"moduleData\";a:10:{s:28:\"dashboard/current_dashboard/\";s:40:\"66552f04f580dafb9440279c195cafebac246cb7\";s:10:\"FormEngine\";a:2:{i:0;a:13:{s:32:\"2258d9587529a9ea12f96ce7d90372b3\";a:5:{i:0;s:4:\"News\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:3;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=e9913855a7475ebeeda45ccc7c5d11cd03fff2bf&id=3\";}s:32:\"7d9e144e24486a6668d151356ea4c9d4\";a:5:{i:0;s:4:\"List\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:4;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=e9913855a7475ebeeda45ccc7c5d11cd03fff2bf&id=4\";}s:32:\"c312013d83c1a6ad7fec8b36a37ba3c8\";a:5:{i:0;s:11:\"Latest News\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:1;s:3:\"pid\";i:6;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=6&table=&pointer=1\";}s:32:\"4869cf322808343c3d6ca616a691b6a3\";a:5:{i:0;s:12:\"Python sucks\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}s:32:\"0d1c7dfc75595e7311ece17f44305463\";a:5:{i:0;s:23:\"C Plus Plus is the best\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:2;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}s:32:\"45c776bcfdb3b1f389c0eee97ec316b5\";a:5:{i:0;s:36:\"Java sucks, delete it from the world\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:3;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}s:32:\"86205c5935270b8ee413592ec1b62292\";a:5:{i:0;s:25:\"Main TypoScript Rendering\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=1&table=&pointer=1\";}s:32:\"750043f9a02785cc6557d2efe33fd403\";a:5:{i:0;s:6:\"Latest\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=6&table=&pointer=1\";}s:32:\"64ed4aefdecb75409ac4c8e6f107b333\";a:5:{i:0;s:10:\"aleksandar\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:2;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:83:\"/typo3/module/system/user-management?token=853e5e0539347ec4367dfb245b80b63ff58e5476\";}s:32:\"581106f297d9eed8dec1190ee4d6b04d\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:3;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B3%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:3;s:3:\"pid\";i:5;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=5&table=&pointer=1\";}s:32:\"3af505b920348c1a79bf62ea28cbec90\";a:5:{i:0;s:6:\"Detail\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:5;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=5&table=&pointer=1\";}s:32:\"97db8c9f61ea241ff1e088650109a099\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:4;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B4%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:4;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}s:32:\"fe7074c4b0d5bc578f49009883c1f002\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:25:\"tx_news_domain_model_news\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:48:\"&edit%5Btx_news_domain_model_news%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:25:\"tx_news_domain_model_news\";s:3:\"uid\";i:5;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}}i:1;s:32:\"45c776bcfdb3b1f389c0eee97ec316b5\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:1:{s:6:\"action\";s:17:\"typoscript_active\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:16:\"opendocs::recent\";a:7:{s:32:\"deac478137dd48a97e299bd046412e21\";a:5:{i:0;s:12:\"List of News\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:2;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=4&table=&pointer=1\";}s:32:\"37a926f6067a3b35f828de1212b08f18\";a:5:{i:0;s:4:\"test\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_category\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_category%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_category\";s:3:\"uid\";i:1;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=3&table=&pointer=1\";}s:32:\"3af505b920348c1a79bf62ea28cbec90\";a:5:{i:0;s:6:\"Detail\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:5;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B5%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:5;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=5&table=&pointer=1\";}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:5:{i:0;s:4:\"Home\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=1&table=&pointer=1\";}s:32:\"86205c5935270b8ee413592ec1b62292\";a:5:{i:0;s:25:\"Main TypoScript Rendering\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=1&table=&pointer=1\";}s:32:\"750043f9a02785cc6557d2efe33fd403\";a:5:{i:0;s:6:\"Latest\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:6;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=6&table=&pointer=1\";}s:32:\"20ed475662b97ac33d3aa853a74f9c9c\";a:5:{i:0;s:7:\"Storage\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:2;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B2%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:2;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:91:\"/typo3/module/web/list?token=15f43baf78f4ce6689a3c6ae9574187b2362c903&id=2&table=&pointer=1\";}}s:16:\"browse_links.php\";a:1:{s:10:\"expandPage\";s:1:\"5\";}s:23:\"backend_user_management\";a:0:{}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";s:2:\"50\";s:20:\"edit_docModuleUpload\";i:1;s:15:\"moduleSessionID\";a:10:{s:28:\"dashboard/current_dashboard/\";s:40:\"5dac00f40781a937168eb6eee2cde26ece310222\";s:10:\"FormEngine\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";s:6:\"web_ts\";s:40:\"5dac00f40781a937168eb6eee2cde26ece310222\";s:25:\"web_typoscript_infomodify\";s:40:\"5dac00f40781a937168eb6eee2cde26ece310222\";s:17:\"typoscript_active\";s:40:\"5dac00f40781a937168eb6eee2cde26ece310222\";s:16:\"opendocs::recent\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";s:16:\"browse_links.php\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";s:23:\"backend_user_management\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";s:10:\"system_log\";s:40:\"ed2fe678e71418c8a7f0e62538d61773478c9249\";}s:10:\"modulemenu\";s:2:\"{}\";s:17:\"systeminformation\";s:40:\"{\"system_log\":{\"lastAccess\":1749212734}}\";s:8:\"realName\";s:0:\"\";s:5:\"email\";s:0:\"\";s:8:\"password\";s:0:\"\";s:9:\"password2\";s:0:\"\";s:6:\"avatar\";s:0:\"\";s:4:\"lang\";s:0:\"\";s:11:\"startModule\";s:0:\"\";s:25:\"showHiddenFilesAndFolders\";i:0;s:10:\"copyLevels\";s:0:\"\";s:18:\"resetConfiguration\";s:0:\"\";s:12:\"mfaProviders\";s:0:\"\";s:18:\"backendTitleFormat\";s:10:\"titleFirst\";s:11:\"colorScheme\";s:4:\"auto\";s:5:\"theme\";s:6:\"modern\";s:11:\"newsoverlay\";s:1:\"0\";}',0,NULL,'','aleksandar','$argon2i$v=19$m=65536,t=16,p=1$SmNLYTFVWC5jLkQuMmJyMg$z+SxtybpR65snd51RSzSByxYUNrg4gHyc+7fd2L5rdY','',0,NULL,'','aleksandar.jovancic@hotbytes.de','Aleksandar Jovancic',1,3,NULL,1,NULL,'',NULL,1749196709,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `expires` int unsigned NOT NULL DEFAULT '0',
  `content` longblob DEFAULT (NULL),
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `expires` int unsigned NOT NULL DEFAULT '0',
  `content` longblob DEFAULT (NULL),
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `expires` int unsigned NOT NULL DEFAULT '0',
  `content` longblob DEFAULT (NULL),
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES (1,'5_403141803c49eb76',1749299545,_binary 'x��Y\�n\�6�=\���\rZ�s\�\\=v\�8i\�n�۴\�.J\�K�@R�h�}����\�\�\�I\�;\�hF��\�\�b�T3#��\�#\���\�g��.���ŵ��#��7�ʭ\�m�_\�\�h���=??��\�\�Kl����\��R����\�B\���\�\�̄\�,J�6\��]uf�h/?\�tX�u�H\�6\"4\�\n���\�-bV\�G�\�dn\n�e�f�PE*�Ù��\�\r\�q�\�B0U��U\�H�S�6{\�s��\�ׯ5\�\�F\�0�V\�4�X��^⟹)�f�7�\�D�g<�Y*#���y���o�뽼x\�m��TQi�N,\�\�ΰ?3��Ϭ\�^|�:F�\�j\�\�b���\�YyC6�\�b\�\�\��\�\�\��`h���Ela���\n5\�*�\�;����Ҧ\�\�[~˙)�s�b�\nr���TFB��\�˞�m�`\�p\�q�Ѐ[��M�\��\�|��2�KiY�N\rj\�6��[x�r�DX\�c�\�\\h\�K\�\�8P\�S���S���h2\�\�\�(��\�R�\rҝ3GVۍcqۥ\�\�\�\�(ӧ\�\�u.6源�\�\�\�xD>~~엟\�8�K⢥\�Th\"{��G�\�+-�\�Z\�\r7\�q(\�\�0�y8��\�\�\�l:�\�f\�\�x5�\�\�x\�ܚ�8H�T\�7ȼ\�80�J�I��K�X>��Ȋ7�_Ӌ�\�M��q4�y4^�f�q8��G�p8\��\�U4\�\�\�`z8\���\�Q�2K�@�)�����r�\�p6D\�t2��g\�\�t\�\��h��\�\�w\nE\��Z\�|0�\��\�G�\�c���Մ\�|5�\�\�p5�M�h�G<������9E�r#�\�<P�پ\�̈\�*�Ow��$!�z�=.CW\�,\'\�\�\Z�k�ݳ�[\�\�\�L!<Ja\�q��V\�ܳ�/S��E\�\�q\�E/u��\�J��C\�\�\���\��W��\��\��ۻ\� o�_\�[\�\�(\�c0\\]��\�u��[�̠ˢ?\����\�!_\�u%\"\�s~�\��\�Z���(xB;\",$ǒ\�\�/!�\�S�\�Ջ\�+\�V-�9\'\����{���l�\Zct1\�\���)x\�\�S\'�\�v�h�4Vf��2-^�!�!Q4\�:�	�\�\�����\�JͭGĵ�\�G-�j{\�l�h��A\�Zi)�S�#Zo�*�\�\�r��\�C\�\�	�+�!n\�\�\�;��W\�)b7h�{�5�\�\�:V|�A\�]��siq\�[\�\�\�b�d�\��N��˜�ĝJ\�\�\�\�\�h^4�ڦ�3��Z�e2<y�T\�\�\�%\�!�\�Yi\�y\�\�\�+i1m��FU(�_\"�\'\�2=A;Y\Z��|}�\�\�T��K�\�&:�\�����V�2��l)\�\�EX��K��n�\�\��\�ΤU@|)�q\0\�b�l\�w	�\�F��\�\'�\�\�\��Q;x��\�\"yb�Z�qna��F	*\�a%\�\�s\�V�0#mTd<,1L�طee\�o��ðLը\���5�\�]\�\�\r�<S`�Ie\�p\�yr\�\�J\�%-\�瀛\0���e���\�oD��\��\n��_�\��]A#OS\�̈́\���ɞ��\0T�30b�J\�.K\0rQ\�\�K\�B\�#��d2��&\0�>\���\�&�`v\�{+\�A.32#�\�\�j*\�B�\�g%�=%�\nwՌ� \'\�B\�_�\'2�+\�W\�8fv�X^f!��w�s��zMT\�\n��=?�\�YEܱR1\�\�E\�*w�Q\�\�Y\�X�\r\�\�Ą�J��4��\��\0�ԭM��Ch� \�<E��$�G�\�œ�=bYE/\�1� \��ּzH\�ŗG�\�]@��A�WT+d� O�;PQޣ0Y\����\\�\�J\"��N)\r+�\�$G�S�$`J\�7�z\�ej�}%\�\Z͝��T��\��IԆ�\��g\�,B���	�F�(|Sd\"W\�:a0¯�h����9Nhp\�QN\���\�C$\\\�l�\�3q\�\�\�\�\�-R��\�C�\�!�!;�\�\���*�V�H\"p�\�9|mq�4F�T\�\"RԔi\�vُ�w�b�P7U\�\�2#�;�骇�%,L5͸�l\�\�X�FY��\�k�B�Ϋ�\�\n\�P�(��>�l���/�;�M�i3k]\�x}����D\�\"�ɔ^�r-\��\� �\�\rQ\���f�su�ܰ�\�(�T�\�F\�Q[\�.;\�\�\�Ć�Lcb\�Y�(.8op@G4\\\�@�u\�=N\nG\�\�\�^�\'p��FT#\�uS$\�M0*\�Ȕ\�\�Oً���\�`��D�\�u7�\�t;\�;�)���Ix\�\�\�=�TX\�\r�+Ξ�\�>\�\"o��CP\�+,\�\���\�a\� ��-��a\�e�1\�|\n �\�h�\�%]-tMܕ$h i�\�\�@b�]�jC˯|\�ѵ�l�p�;Ut\\\�Ԧ.%ڤ\�[�z4�1�OSE��g]R7�\�� nI\�+@\�\�S{�>�>g���P��\��\�\�\�(�\�X#y\�R��8,0j� Z\�2\�4�lU\��\�7��z\�uwS\�!܅�2[\�@�b\��v\\��\�\��YEt\�`v�ex\�EBc\�C��`\�6c�\�m�4��\Zu\�-QRr�\�Zv\�B�<S�\�y�h,\�\�/#M\�[�p����6\�&\�!`�\�\��\�n\�Ÿ\�\�ЅY�6\��\�oۆKN\�ڂsj#8\�){[\�\�\�\�Olx\�n\�G\�\�)\�+VP\�ts���\r����\�\�aLN\�u��;��p\�\�C\�;�u�\�nY�uZ�\��t�%�ß~\�tr�;j\�\�\�\�dw\�دX�I\�\�U\�\�\�#���\�\��h������;�\�\��]�@�\�!}�B�D\�\��ϷC\�\�\�\�\�|��\�\'S>�\�`>�\�\'�x4�\�\��p0�̓���h\�0�\�\�\��۴\�\�u�\�?\�4�\�j�}�\�)���\�z\�v\�5�Rۋ�����{\��`w\�}E��x5<\\t\�rDG�l�M[��\�\�͕̣K��#�\�/~�+��+\�t�ܯ�;\�+ʭS�V�\r\�\��\�\�_\n�\�oQ�B�D\�ӥP�\�\�V\�\�A\�\']�A*h-�XVн>ݖ\r��!]\�F��n�s\�/-\�Nl�P\0\�[�\�\�\�b񧬴\�2�\�w&\�\�[�\�/u�\�\�$Yu\�׆X\�?\�E�h\��\�\�\�\�u��\�[\�_�\��\�Snk�ތ���\�u�\�tM\�!\�o\�\�í-5Y)c�0�\��C\"�<�\�-L�|\�\0g�\�K�\��̰2\�V�\�d\�/Nw\�Z���\�\�1<�˿9\�\�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES (1,'5_403141803c49eb76','pages_5'),(2,'5_403141803c49eb76','tt_content_3'),(3,'5_403141803c49eb76','tx_news'),(4,'5_403141803c49eb76','tx_news_domain_model_news_3'),(5,'5_403141803c49eb76','tx_news_uid_3'),(6,'5_403141803c49eb76','tx_news_domain_model_news_2'),(7,'5_403141803c49eb76','tx_news_uid_2'),(8,'5_403141803c49eb76','sys_category_1'),(9,'5_403141803c49eb76','pageId_5');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `expires` int unsigned NOT NULL DEFAULT '0',
  `content` longblob DEFAULT (NULL),
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES (1,'5__0_0_0_0',1751805145,_binary 'x�\�VMo\�6�/:]Ɏ��Ӣ)��\"g=�H˄%R%�\�F��ޡ�!\�\�\ntA�\�\�|CgF3z\�z$h�Do\Z\�Q1pZ<r�xW�[U�Z�\�hC�~V�j�\\\�6\�R+JK,�\�\n,+TP\�2\�F/�\�{\��2�\r*��2�w,`p�	�\"kT\�n�\�z�JTn��\�p\�\�}\���T(yzb�V�7\\\�E\�\��ܴ�>�Ģ/\Z�D4i\����\nmU\n\�ń���T��\�\0��\n\�\�j\�1\�\���\�(\�ַ�ʣ�\���<~)\�\��\�vh\�?A^qjv\�\�\�H�l\�a���\�W{ٶ\�\�5R𚴸\�\�\�r\�:\�\��\0\�`{\��\�\�^q���8T6\�\���	\00\�AM}�\'nS\�\0ݜ�;\�k��C\�NEj\�VGv9IE��\r\� U�C\n�uHK��\�\�f��\��;\�\�U��uG\�#�!Nw\�\�lp\�^�?RKa�]\�^\�\�\�q\�\�0�_��}z�4>��-��\�\�\�Q\��-�C��b�M\�\�$Be;\�s\�/\�О÷u;@���u�/@��\���\�؂�=�t\\�u�3�M_\�v\�\�\�\��=qbݞ0~>i\�\Zh��\�jf{/;��+|{�\�f��\�\'֡~\��\�πۘ\�44S\�\�\�\�󀏑\�N,:���d�\�f\�\�\�\�겓\�=�i�\���y�\�ۗ\�\���4\�\�f=�;�\�и�L\�V7\�5qh\'0�9�3�Q\�\�=�J7)�Y\�m\��\�O���<�C\�n~�?1c�\n��#m�S�h4@�\�\'\�\�fݛT7鈉\�\�\"?~I\�7\�6�ab\�\�\�\ZM�\�s�\�\r��]\�Gu¬\"�6F	HHd�\�!\�9�\Z\�,\�8\��o�@�\�\�K\�s�Jb$>W\�\neJt/�\�@��!��f(�\�\�_\�J^������]�e,\�z\�>I��p\�\�q���ŵ1�\�$4\�\�7�7\�m\�Q5\�\�b��QT\�\�\Z\�\�\�\�\�t-�\�%Q2\�#W\�>Y�\�d7\�A���m�\�\nj�\\T\���k0�۴o_�U\�*,\�\n׋\r�\�w^��\�{�\n�/\�\�gah���*|��BW}K\�%t�/t�t_\�V�\�B}\�Ev\�o�9�ŧ�+p\�O��\���)p�3�{��\�[�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `tag` varchar(250) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES (1,'5__0_0_0_0','pageId_1'),(2,'5__0_0_0_0','pageId_5');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `title` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `subgroup` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  `felogin_redirectPid` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ses_userid` int unsigned NOT NULL DEFAULT '0',
  `ses_tstamp` int unsigned NOT NULL DEFAULT '0',
  `ses_data` mediumblob DEFAULT (NULL),
  `ses_permanent` smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `disable` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `tx_extbase_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `uc` blob DEFAULT (NULL),
  `is_online` int unsigned NOT NULL DEFAULT '0',
  `mfa` mediumblob DEFAULT (NULL),
  `felogin_forgotHash` varchar(80) COLLATE utf8mb4_general_ci DEFAULT '',
  `username` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `password` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `usergroup` varchar(512) COLLATE utf8mb4_general_ci DEFAULT '',
  `name` varchar(160) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `first_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `middle_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `last_name` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `address` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `telephone` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `fax` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `title` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `zip` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `city` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `country` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `www` varchar(80) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `company` varchar(80) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `image` int unsigned NOT NULL DEFAULT '0',
  `lastlogin` bigint NOT NULL DEFAULT '0',
  `felogin_redirectPid` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `fe_group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `rowDescription` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `editlock` smallint unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_source` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `perms_userid` int unsigned NOT NULL DEFAULT '0',
  `perms_groupid` int unsigned NOT NULL DEFAULT '0',
  `perms_user` smallint unsigned NOT NULL DEFAULT '0',
  `perms_group` smallint unsigned NOT NULL DEFAULT '0',
  `perms_everybody` smallint unsigned NOT NULL DEFAULT '0',
  `SYS_LASTCHANGED` int unsigned NOT NULL DEFAULT '0',
  `shortcut` int unsigned NOT NULL DEFAULT '0',
  `content_from_pid` int unsigned NOT NULL DEFAULT '0',
  `mount_pid` int unsigned NOT NULL DEFAULT '0',
  `tx_impexp_origuid` int NOT NULL DEFAULT '0',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT '0.5',
  `doktype` int unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `slug` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `TSconfig` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `php_tree_stop` smallint unsigned NOT NULL DEFAULT '0',
  `categories` int unsigned NOT NULL DEFAULT '0',
  `layout` int unsigned NOT NULL DEFAULT '0',
  `extendToSubpages` smallint unsigned NOT NULL DEFAULT '0',
  `nav_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `nav_hide` smallint unsigned NOT NULL DEFAULT '0',
  `subtitle` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `target` varchar(80) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `url` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `lastUpdated` bigint NOT NULL DEFAULT '0',
  `newUntil` bigint NOT NULL DEFAULT '0',
  `cache_timeout` int unsigned NOT NULL DEFAULT '0',
  `cache_tags` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `no_search` smallint unsigned NOT NULL DEFAULT '0',
  `shortcut_mode` int unsigned NOT NULL DEFAULT '0',
  `keywords` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `abstract` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `author` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `media` int unsigned NOT NULL DEFAULT '0',
  `is_siteroot` smallint unsigned NOT NULL DEFAULT '0',
  `mount_pid_ol` smallint NOT NULL DEFAULT '0',
  `module` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `l18n_cfg` smallint unsigned NOT NULL DEFAULT '0',
  `backend_layout` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `tsconfig_includes` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `no_index` smallint unsigned NOT NULL DEFAULT '0',
  `no_follow` smallint unsigned NOT NULL DEFAULT '0',
  `sitemap_changefreq` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `canonical_link` text COLLATE utf8mb4_general_ci NOT NULL DEFAULT (_utf8mb3''),
  `og_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `og_description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `og_image` int unsigned NOT NULL DEFAULT '0',
  `twitter_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `twitter_description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `twitter_image` int unsigned NOT NULL DEFAULT '0',
  `twitter_card` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,0,1748595958,1748595958,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1748595958,0,0,0,0,0.5,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),(2,1,1749196762,1749196743,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,_binary '{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"hidden\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'Storage','/storage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),(3,2,1749196770,1749196748,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,_binary '{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"hidden\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0,0.5,254,'News','/news',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),(4,1,1749196822,1749196793,0,0,0,0,'',128,NULL,0,0,0,0,NULL,_binary '{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,1749197128,0,0,0,0,0.5,1,'List','/list',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),(5,1,1749196829,1749196797,0,0,0,0,'',64,NULL,0,0,0,0,NULL,_binary '{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,1749199823,0,0,0,0,0.5,1,'Detail','/detail',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,''),(6,1,1749196836,1749196802,0,0,0,0,'',32,NULL,0,0,0,0,NULL,_binary '{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,2,0,31,27,0,1749202538,0,0,0,0,0.5,1,'Latest','/latest',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','',NULL,'',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `userid` int unsigned NOT NULL DEFAULT '0',
  `route` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `arguments` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `description` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `sorting` int NOT NULL DEFAULT '0',
  `sc_group` smallint NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `items` int NOT NULL DEFAULT '0',
  `images` int unsigned DEFAULT '0',
  `single_pid` int unsigned NOT NULL DEFAULT '0',
  `shortcut` int NOT NULL DEFAULT '0',
  `import_id` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `import_source` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `seo_description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `seo_headline` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `seo_text` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `slug` varchar(2048) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `parent` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES (1,3,1749201291,1749201291,0,0,0,0,256,'',0,0,NULL,'',0,0,0,0,0,0,0,0,'','','','','','','test','test',0);
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int unsigned NOT NULL DEFAULT '0',
  `uid_foreign` int unsigned NOT NULL DEFAULT '0',
  `sorting` int unsigned NOT NULL DEFAULT '0',
  `sorting_foreign` int unsigned NOT NULL DEFAULT '0',
  `tablenames` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES (1,3,0,1,'tx_news_domain_model_news','categories');
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  `created` int unsigned NOT NULL,
  `scope` varchar(264) COLLATE utf8mb4_general_ci NOT NULL,
  `mutation_identifier` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `mutation_collection` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `meta` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `last_indexed` int NOT NULL DEFAULT '0',
  `identifier` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `identifier_hash` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `folder_hash` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `extension` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `sha1` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `creation_date` int NOT NULL DEFAULT '0',
  `modification_date` int NOT NULL DEFAULT '0',
  `storage` int unsigned NOT NULL DEFAULT '0',
  `type` int unsigned NOT NULL DEFAULT '0',
  `mime_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `size` int NOT NULL DEFAULT '0',
  `missing` smallint unsigned NOT NULL DEFAULT '0',
  `metadata` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES (1,0,1749197188,1749197188,'/_assets/f6ef6adaf5c92bf687a31a3adbcb0f7b/Images/dummy-preview-image.png','35bdcfc42903a4189e40028928741a79bc48cf24','557d1939219cbaef9f24c50a9ca50baf799cfe0a','png','dummy-preview-image.png','b069aa085f06da6743b904400b0e412c3b0b5b07',1748590043,1748590043,0,2,'image/png',25896,0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `type` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'static',
  `files` int unsigned NOT NULL DEFAULT '0',
  `folder_identifier` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `recursive` smallint unsigned NOT NULL DEFAULT '0',
  `category` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `alternative` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `categories` int unsigned NOT NULL DEFAULT '0',
  `file` int unsigned NOT NULL DEFAULT '0',
  `description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `width` int NOT NULL DEFAULT '0',
  `height` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES (1,0,1749197188,1749197188,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,128,128);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int NOT NULL AUTO_INCREMENT,
  `tstamp` int NOT NULL DEFAULT '0',
  `crdate` int NOT NULL DEFAULT '0',
  `storage` int NOT NULL DEFAULT '0',
  `original` int NOT NULL DEFAULT '0',
  `identifier` varchar(512) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `name` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `processing_url` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `configuration` blob DEFAULT (NULL),
  `configurationsha1` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `task_type` varchar(200) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `checksum` varchar(32) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `width` int DEFAULT '0',
  `height` int DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES (1,1749197188,1749197188,0,1,'/typo3temp/assets/_processed_/6/6/csm_dummy-preview-image_fa674c2562.png','csm_dummy-preview-image_fa674c2562.png',NULL,_binary 'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:100;s:9:\"maxHeight\";i:100;s:4:\"crop\";N;}','1de85feb3e25752eaaeafd731583414ea1d5b62a','b069aa085f06da6743b904400b0e412c3b0b5b07','Image.CropScaleMask','fa674c2562',100,100);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `uid_local` int NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `alternative` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `showinpreview` smallint NOT NULL DEFAULT '0',
  `uid_foreign` int NOT NULL DEFAULT '0',
  `tablenames` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `fieldname` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `sorting_foreign` int NOT NULL DEFAULT '0',
  `link` text COLLATE utf8mb4_general_ci NOT NULL DEFAULT (_utf8mb3''),
  `description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `crop` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `autoplay` smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `is_public` smallint NOT NULL DEFAULT '0',
  `processingfolder` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `is_browsable` smallint unsigned NOT NULL DEFAULT '1',
  `is_default` smallint unsigned NOT NULL DEFAULT '0',
  `is_writable` smallint unsigned NOT NULL DEFAULT '1',
  `is_online` smallint unsigned NOT NULL DEFAULT '1',
  `auto_extract_metadata` smallint unsigned NOT NULL DEFAULT '1',
  `driver` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `configuration` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES (1,0,1749196757,1749196757,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `identifier` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `read_only` smallint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `actiontype` smallint NOT NULL DEFAULT '0',
  `usertype` varchar(2) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'BE',
  `userid` int unsigned DEFAULT NULL,
  `originaluserid` int unsigned DEFAULT NULL,
  `recuid` int NOT NULL DEFAULT '0',
  `tablename` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `history_data` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `workspace` int DEFAULT '0',
  `correlation_id` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES (1,1748596243,2,'BE',2,0,1,'sys_template','{\"oldRecord\":{\"config\":\"page = PAGE\\npage.10 = TEXT\\npage.10.value (\\n   <div style=\\\"width: 800px; margin: 15% auto;\\\">\\n      <div style=\\\"width: 300px;\\\">\\n        <svg xmlns=\\\"http:\\/\\/www.w3.org\\/2000\\/svg\\\" viewBox=\\\"0 0 150 42\\\"><path d=\\\"M60.2 14.4v27h-3.8v-27h-6.7v-3.3h17.1v3.3h-6.6zm20.2 12.9v14h-3.9v-14l-7.7-16.2h4.1l5.7 12.2 5.7-12.2h3.9l-7.8 16.2zm19.5 2.6h-3.6v11.4h-3.8V11.1s3.7-.3 7.3-.3c6.6 0 8.5 4.1 8.5 9.4 0 6.5-2.3 9.7-8.4 9.7m.4-16c-2.4 0-4.1.3-4.1.3v12.6h4.1c2.4 0 4.1-1.6 4.1-6.3 0-4.4-1-6.6-4.1-6.6m21.5 27.7c-7.1 0-9-5.2-9-15.8 0-10.2 1.9-15.1 9-15.1s9 4.9 9 15.1c.1 10.6-1.8 15.8-9 15.8m0-27.7c-3.9 0-5.2 2.6-5.2 12.1 0 9.3 1.3 12.4 5.2 12.4 3.9 0 5.2-3.1 5.2-12.4 0-9.4-1.3-12.1-5.2-12.1m19.9 27.7c-2.1 0-5.3-.6-5.7-.7v-3.1c1 .2 3.7.7 5.6.7 2.2 0 3.6-1.9 3.6-5.2 0-3.9-.6-6-3.7-6H138V24h3.1c3.5 0 3.7-3.6 3.7-5.3 0-3.4-1.1-4.8-3.2-4.8-1.9 0-4.1.5-5.3.7v-3.2c.5-.1 3-.7 5.2-.7 4.4 0 7 1.9 7 8.3 0 2.9-1 5.5-3.3 6.3 2.6.2 3.8 3.1 3.8 7.3 0 6.6-2.5 9-7.3 9\\\"\\/><path fill=\\\"#FF8700\\\" d=\\\"M31.7 28.8c-.6.2-1.1.2-1.7.2-5.2 0-12.9-18.2-12.9-24.3 0-2.2.5-3 1.3-3.6C12 1.9 4.3 4.2 1.9 7.2 1.3 8 1 9.1 1 10.6c0 9.5 10.1 31 17.3 31 3.3 0 8.8-5.4 13.4-12.8M28.4.5c6.6 0 13.2 1.1 13.2 4.8 0 7.6-4.8 16.7-7.2 16.7-4.4 0-9.9-12.1-9.9-18.2C24.5 1 25.6.5 28.4.5\\\"\\/><\\/svg>\\n      <\\/div>\\n      <h4 style=\\\"font-family: sans-serif;\\\">Welcome to a default website made with <a href=\\\"https:\\/\\/typo3.org\\\">TYPO3<\\/a><\\/h4>\\n   <\\/div>\\n)\\npage.100 = CONTENT\\npage.100 {\\n    table = tt_content\\n    select {\\n        orderBy = sorting\\n        where = {#colPos}=0\\n    }\\n}\\n\",\"description\":\"This is an Empty Site Package TypoScript record.\\n\\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"},\"newRecord\":{\"config\":\"\",\"description\":\"This is an Empty Site Package TypoScript record.\\r\\n\\r\\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject\\/Configuration\\/TypoScript\\/setup.typoscript\'\"}}',0,'0400$0e365e020c991a6b074b7c090d8ddb16:35af6288617af54964e77af08c30949a'),(2,1748596269,2,'BE',2,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/\"},\"newRecord\":{\"include_static_file\":\"EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/,EXT:fluid_styled_content\\/Configuration\\/TypoScript\\/Styling\\/,EXT:news\\/Configuration\\/TypoScript,EXT:site_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript\\/SeoSitemap\"}}',0,'0400$7556e3e8d1bc94376e9a2b74dcef684f:35af6288617af54964e77af08c30949a'),(3,1749196743,1,'BE',2,0,2,'pages','{\"doktype\":\"254\",\"slug\":\"\\/storage\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Storage\",\"sys_language_uid\":0,\"crdate\":1749196743,\"t3ver_stage\":0,\"tstamp\":1749196743,\"uid\":2}',0,'0400$c3ad5a45a1f01723937499c933aaf19f:f11830df10b4b0bca2db34810c2241b3'),(4,1749196748,1,'BE',2,0,3,'pages','{\"doktype\":\"254\",\"slug\":\"\\/news\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"News\",\"sys_language_uid\":0,\"crdate\":1749196748,\"t3ver_stage\":0,\"tstamp\":1749196748,\"uid\":3}',0,'0400$7509a13eae020546da33cc17ced7f846:fe15eeb7d49e64e2cea91ab53fcf0db1'),(5,1749196762,2,'BE',2,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$bb6b520415e849f7b4e11396500cad7e:f11830df10b4b0bca2db34810c2241b3'),(6,1749196770,2,'BE',2,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$b1fc028a553908eceafb85aa47885557:fe15eeb7d49e64e2cea91ab53fcf0db1'),(7,1749196793,1,'BE',2,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/list\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":128,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"List\",\"sys_language_uid\":0,\"crdate\":1749196793,\"t3ver_stage\":0,\"tstamp\":1749196793,\"uid\":4}',0,'0400$b7d323da43127abe9a68b64ed8cf9a4a:412add0b3eb6ec8f1cb6710aea92e21e'),(8,1749196797,1,'BE',2,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/detail\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":64,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Detail\",\"sys_language_uid\":0,\"crdate\":1749196797,\"t3ver_stage\":0,\"tstamp\":1749196797,\"uid\":5}',0,'0400$d0138e8643b244fb07dd9b85c42a490c:7ef5a4e3e11db8ac3fea4d7a75468161'),(9,1749196802,1,'BE',2,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/latest\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":1,\"sorting\":32,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Latest\",\"sys_language_uid\":0,\"crdate\":1749196802,\"t3ver_stage\":0,\"tstamp\":1749196802,\"uid\":6}',0,'0400$a8dc3537bdd647833252c342cc46bbe3:c75354c439a48dbde16b03ac553a080d'),(10,1749196811,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"nav_hide\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"nav_hide\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$e94995065ad68aab46ac0dfc7b323147:412add0b3eb6ec8f1cb6710aea92e21e'),(11,1749196822,2,'BE',2,0,4,'pages','{\"oldRecord\":{\"nav_hide\":1},\"newRecord\":{\"nav_hide\":\"0\"}}',0,'0400$f891755c3d6b607e925de3a51908e284:412add0b3eb6ec8f1cb6710aea92e21e'),(12,1749196829,2,'BE',2,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"nav_hide\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"nav_hide\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$2e586b2dbf250362ffa6fbd0f36cea20:7ef5a4e3e11db8ac3fea4d7a75468161'),(13,1749196836,2,'BE',2,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$98d21ef46204b3b2e7a1f4a52ffb0b78:c75354c439a48dbde16b03ac553a080d'),(14,1749196931,1,'BE',2,0,1,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":6,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">crdate<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1749196931,\"t3ver_stage\":0,\"tstamp\":1749196931,\"uid\":1}',0,'0400$20f910e8e7739c2227862d0864e65f78:7fa2c035f26826fe83eeecaaeddc4d40'),(15,1749196969,1,'BE',2,0,2,'tt_content','{\"CType\":\"news_newsliststicky\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1749196969,\"t3ver_stage\":0,\"tstamp\":1749196969,\"uid\":2}',0,'0400$beb0a8d0c75f814637231b99ad63ccff:01dbc21fdb1263685b9147b3b1596ea8'),(16,1749197032,1,'BE',2,0,1,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"python-sucks\",\"sitemap_priority\":\"0.5\",\"pid\":3,\"type\":\"0\",\"title\":\"Python sucks\",\"teaser\":\"This is why python sucks\",\"datetime\":1749196984,\"archive\":0,\"bodytext\":\"<h2>Why Python Sucks (But Everyone\\u2019s Too Polite to Say It)<\\/h2>\\r\\n<ul><li><strong>\\u201cReadability counts\\u201d<\\/strong> \\u2014 unless you\'re reading <i>someone else\'s<\\/i> Python code, in which case it\'s 2,000 lines of unexplained magic using libraries you\'ve never heard of, written with indentation so aggressive it could start a war.<\\/li><li><strong>Whitespace is syntax.<\\/strong> One misplaced space and your whole script collapses like a poorly constructed IKEA shelf. Want tabs and spaces together? Python says: <i>\\\"Go to jail.\\\"<\\/i><\\/li><li><strong>Dynamic typing?<\\/strong> Feels great until your function that was returning a string suddenly returns a list, then a dictionary, then a goat. And you don\\u2019t find out until runtime \\u2014 surprise!<\\/li><li><strong>It\\u2019s slow.<\\/strong> Python is slower than a snail on melatonin. Want to process a million rows of data? Better make a coffee. Or two. Maybe go on a weekend retreat.<\\/li><li><strong>Global Interpreter Lock (GIL).<\\/strong> Ah yes, multithreading \\u2014 but only one thread can run at a time. You can import threading, but it\\u2019s just cosplay. True parallelism? Not here.<\\/li><li><strong>Error messages?<\\/strong> Sometimes helpful. Other times: <i>\\\"NoneType object has no attribute \'wiggle\\u2019.\\u201d<\\/i> Oh thanks Python, that really narrows it down.<\\/li><li><strong>Duck typing.<\\/strong> \\u201cIf it quacks like a duck\\u2026\\u201d \\u2014 but sometimes it explodes like a grenade, and Python just shrugs and calls it \\u201cflexible.\\u201d<\\/li><li><strong>Packaging hell.<\\/strong> Pip, pipenv, poetry, virtualenv, conda \\u2014 it\'s like five competing religions fighting over the same package manager. And none of them work exactly right.<\\/li><li><strong>Version anxiety.<\\/strong> Python 2 or 3? Hope you picked right \\u2014 because your dependencies sure didn\\u2019t. Welcome to the kingdom of ImportError.<\\/li><li><strong>Lambda expressions?<\\/strong> Cool idea, but Python neutered them so hard they can barely hold a one-liner. You want an inline function? Good luck. You want logic in that function? Too bad.<\\/li><\\/ul>\\r\\n<h2>Final Thoughts<\\/h2>\\r\\n<p>Python is the friendliest knife in the drawer. It looks cute, it feels nice, and then one day it slices your leg off because you called .strip() on None.<\\/p>\\r\\n<p>It\\u2019s fun for beginners, great for quick scripts, and unbeatable for data science. But when it\\u2019s time to scale, optimize, or maintain \\u2014 well, hope you like duct tape and prayer.<\\/p>\\r\\n<p>Python isn\\u2019t the worst tool in the shed. But it sure is the one with the least safety warnings and the highest accidental amputations.<\\/p>\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1749197032,\"t3ver_stage\":0,\"tstamp\":1749197032,\"uid\":1}',0,'0400$c7ffe41d1e2ae170440b7b0bb5672d45:fccd16ea3664ec003726b2a72ea38f4b'),(17,1749197079,1,'BE',2,0,2,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"c-plus-plus-is-the-best\",\"sitemap_priority\":\"0.5\",\"pid\":3,\"type\":\"0\",\"title\":\"C Plus Plus is the best\",\"teaser\":\"why cpp is the best language ever\",\"datetime\":1749197039,\"archive\":0,\"bodytext\":\"<h2>Why C++ is the Best (Totally Objective, Absolutely Serious)<\\/h2>\\r\\n<ul><li><strong>Do you enjoy pain?<\\/strong> Excellent. C++ isn\\u2019t just a programming language; it\\u2019s a rite of passage. Segmentation faults, undefined behavior, and error messages that read like ancient curses \\u2014 what\\u2019s not to love?<\\/li><li><strong>Memory management?<\\/strong> Forget garbage collectors. In C++, <i>you<\\/i> are the garbage collector. Allocate memory with new, deallocate it with delete, forget one? Enjoy the memory leak. It builds character.<\\/li><li><strong>Syntax?<\\/strong> It\\u2019s elegant \\u2014 in the same way an old cathedral is elegant: intricate, mysterious, and maybe haunted. One line of C++ can either sort a list or summon a compiler demon.<\\/li><li><strong>Templates?<\\/strong> Want code that looks like math homework from the fourth dimension? Want to write something once and break in ten ways on ten compilers? Templates. Beautiful, monstrous templates.<\\/li><li><strong>Multi-paradigm power.<\\/strong> C++ lets you write procedural code, object-oriented code, functional code, and existential horror \\u2014 all in the same file. Sometimes in the same function.<\\/li><li><strong>The community?<\\/strong> Gritty, battle-hardened, and fluent in cryptic compiler errors. We don\\u2019t run from danger \\u2014 we override operator&lt;&lt; and run straight into it.<\\/li><li><strong>Cross-platform and timeless.<\\/strong> Whether you\'re writing a game engine, a high-frequency trading bot, or firmware for a microwave, C++ has been there, done that, and probably wrote the standard for it.<\\/li><li><strong>It just works.<\\/strong> After 17 compiler flags, a Makefile incantation, and sacrificing a Java developer to the linker, your program will compile. Maybe. If the stars align.<\\/li><\\/ul>\\r\\n<h2>Final Thoughts<\\/h2>\\r\\n<p>C++ isn\\u2019t just a tool \\u2014 it\\u2019s a test of will. It\\u2019s not the easiest, not the friendliest, but it <i>is<\\/i> the one that makes you feel like you\\u2019ve earned it. If you can write solid C++, everything else feels like child\\u2019s play.<\\/p>\\r\\n<p>Welcome to C++. No safety rails. No excuses. Just you, the code, and the void.<\\/p>\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1749197079,\"t3ver_stage\":0,\"tstamp\":1749197079,\"uid\":2}',0,'0400$a7158b98cd6dfd499920fa37193825ad:640f28e5c1a5ec2efb19c26699b464a5'),(18,1749197110,1,'BE',2,0,3,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"java-sucks-delete-it-from-the-world\",\"sitemap_priority\":\"0.5\",\"pid\":3,\"type\":\"0\",\"title\":\"Java sucks, delete it from the world\",\"teaser\":\"worst ever language made\",\"datetime\":1749197091,\"archive\":0,\"bodytext\":\"<h2>Why Java Sucks (But Only a Little. Maybe.)<\\/h2>\\r\\n<ul><li><strong>\\\"Write once, run anywhere\\\"?<\\/strong> More like <i>\\\"Write once, debug everywhere.\\\"<\\/i> Java promised us platform independence. What we got was a JVM that behaves differently on every machine and a jar file that only runs if Jupiter\\u2019s moons are in retrograde.<\\/li><li><strong>Boilerplate?<\\/strong> Oh, Java loves it. Want to print \\u201cHello, World\\u201d? That\\u2019ll be one class, one method, a public static void main, some curly braces, and your soul.<\\/li><li><strong>Everything is a class.<\\/strong> Need a simple script? Too bad. Everything must live in a class. Even if you\\u2019re just trying to add two numbers, Java\\u2019s dragging you into OOP like a clingy ex.<\\/li><li><strong>Verbose much?<\\/strong> In Java, what takes one line in Python takes ten. Need a list of strings? List&lt;String&gt; myList = new ArrayList&lt;String&gt;(); \\u2014 and that\\u2019s before you even add anything to it.<\\/li><li><strong>Garbage collected?<\\/strong> Yes \\u2014 but not when you want it to be. And when the GC <i>does<\\/i> show up, it might freeze your app just long enough for your users to uninstall it.<\\/li><li><strong>Checked exceptions.<\\/strong> Because what every developer wants is to be <i>forced<\\/i> to handle errors they can\\u2019t possibly recover from. Your code will look like a sea of try\\/catch blocks duct-taped together just to make the compiler happy.<\\/li><li><strong>JavaFX and GUI development?<\\/strong> If you like dragging your eyeballs over XML files and clicking 400 times to get one button to align, Java\\u2019s got you. It\\u2019s like building a house by whispering instructions to a brick.<\\/li><li><strong>The ecosystem.<\\/strong> Want to use a modern framework? Enjoy 17 Maven dependencies, a build process that summons half the internet, and an IDE that cries every time you update one version.<\\/li><li><strong>JVM startup time.<\\/strong> Sure, the code runs eventually. But first it warms up. Slowly. Like a 1998 Toyota Corolla in Siberia.<\\/li><\\/ul>\\r\\n<h2>Closing Arguments<\\/h2>\\r\\n<p>Java isn\\u2019t evil \\u2014 it\\u2019s just the corporate intern that won\\u2019t stop talking about how \\\"enterprise\\\" it is. It\\u2019ll make you write getters, setters, abstract factory beans, and service locators just to say <i>\\\"hello.\\\"<\\/i><\\/p>\\r\\n<p>It\\u2019s not the worst language \\u2014 but it sure tries to be the most annoyingly bureaucratic. If you enjoy coding with a straightjacket and a 500-page instruction manual, Java\\u2019s waiting.<\\/p>\\r\\n<p>Otherwise? Run.<\\/p>\\r\\n<p>Unless the garbage collector already paused you.<\\/p>\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1749197110,\"t3ver_stage\":0,\"tstamp\":1749197110,\"uid\":3}',0,'0400$967068c8533706d5e43a6bc0cc8f3bd7:1152fda277b2623b0152b5765fcb6b28'),(19,1749197122,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Latest News\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$97cf466fbd07ac976204d22f0139f0c9:7fa2c035f26826fe83eeecaaeddc4d40'),(20,1749197128,2,'BE',2,0,2,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"List of News\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$3a50f32c1d831636de3eaa94264aafd0:01dbc21fdb1263685b9147b3b1596ea8'),(21,1749199760,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"event_location\":\"\",\"event_price\":\"\",\"event_website\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"event_location\":\"Gundelsheim\",\"event_price\":\"100 Euro\",\"event_website\":\"https:\\/\\/www.youtube.com\\/watch?v=fCPMZG8J0Mg\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"event_location\\\":\\\"\\\",\\\"event_date\\\":\\\"\\\",\\\"event_organizer\\\":\\\"\\\",\\\"event_price\\\":\\\"\\\",\\\"event_website\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$50ff57cde23956ce0d099d4647ab8728:1152fda277b2623b0152b5765fcb6b28'),(22,1749199764,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"event_organizer\":\"\"},\"newRecord\":{\"event_organizer\":\"Me\"}}',0,'0400$2f474ae8d53aeea478befefe913945b5:1152fda277b2623b0152b5765fcb6b28'),(23,1749199770,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"event_date\":0},\"newRecord\":{\"event_date\":1751618940}}',0,'0400$bf7c1109c792ace7631a0aa5d9d711ff:1152fda277b2623b0152b5765fcb6b28'),(24,1749199823,1,'BE',2,0,3,'tt_content','{\"CType\":\"news_newsdetail\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.singleNews\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1749199823,\"t3ver_stage\":0,\"tstamp\":1749199823,\"uid\":3}',0,'0400$2fd43ffaf4b262045d25c7c1b3b3fa1d:b92300cfb5d1d3645c9cb212a7f56c1f'),(25,1749201291,1,'BE',2,0,1,'sys_category','{\"parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"single_pid\":0,\"shortcut\":0,\"slug\":\"test\",\"pid\":3,\"sorting\":256,\"title\":\"test\",\"items\":\"0\",\"sys_language_uid\":0,\"seo_title\":\"\",\"seo_description\":\"\",\"seo_headline\":\"\",\"seo_text\":\"\",\"description\":\"\",\"crdate\":1749201291,\"t3ver_stage\":0,\"tstamp\":1749201291,\"uid\":1}',0,'0400$141a9dbef2cbed0ac5a4be13ed1f6908:c6c8e24453121a7d668fe4b1031ebf88'),(26,1749201354,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"categories\":\"\",\"related\":\"\"},\"newRecord\":{\"categories\":\"1\",\"related\":\"tx_news_domain_model_news_2\"}}',0,'0400$a3820b1452f5e5874758079dc8f1da58:1152fda277b2623b0152b5765fcb6b28'),(27,1749202332,2,'BE',2,0,2,'be_users','{\"oldRecord\":{\"lang\":\"default\"},\"newRecord\":{\"lang\":\"de\"}}',0,'0400$660e0f90ded3e28e287ff608863c3e27:c98a59192960d7c1b8e415cda9ffe933'),(28,1749202448,2,'BE',2,0,2,'be_users','{\"oldRecord\":{\"lang\":\"de\"},\"newRecord\":{\"lang\":\"default\"}}',0,'0400$6d00e44bce5b27ecfc5b236ba3e4bc0f:c98a59192960d7c1b8e415cda9ffe933'),(29,1749202538,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">crdate<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\">crdate<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\">desc<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\">datetime<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\">3<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">5<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$b79d7005ad6b9d400acad2916be6b936:7fa2c035f26826fe83eeecaaeddc4d40'),(30,1749209503,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"location\":\"\",\"date\":0,\"organizer\":\"\",\"price\":\"\",\"website\":\"\",\"related\":\"2\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"event_location\\\":\\\"\\\",\\\"event_date\\\":\\\"\\\",\\\"event_organizer\\\":\\\"\\\",\\\"event_price\\\":\\\"\\\",\\\"event_website\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"},\"newRecord\":{\"location\":\"gundelsheim\",\"date\":1751023860,\"organizer\":\"aaa\",\"price\":\"100\",\"website\":\"https:\\/\\/www.youtube.com\\/watch?v=QZPvUgdIQ38\",\"related\":\"tx_news_domain_model_news_2\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"location\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"organizer\\\":\\\"\\\",\\\"price\\\":\\\"\\\",\\\"website\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$d38c436a1d9e431af3ff230c0c92ec88:1152fda277b2623b0152b5765fcb6b28'),(31,1749209688,2,'BE',2,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"related\":\"2\"},\"newRecord\":{\"related\":\"tx_news_domain_model_news_2\"}}',0,'0400$b8314cf51dd94738ea163cb6d4e09b32:1152fda277b2623b0152b5765fcb6b28'),(32,1749211047,1,'BE',2,0,4,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"default-8fc87da7fc9a18fb53a05f705bb3dfaa\",\"date\":0,\"sitemap_priority\":\"0.5\",\"pid\":3,\"type\":\"1\",\"teaser\":\"\",\"datetime\":1749211023,\"archive\":0,\"bodytext\":\"\",\"organizer\":\"\",\"price\":\"\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1749211047,\"t3ver_stage\":0,\"tstamp\":1749211047,\"uid\":4}',0,'0400$881220c52cebfe2d673f897cffcfc5c8:f3f39c24ca39d00c02ecd29ec2ad4225'),(33,1749211050,2,'BE',2,0,4,'tx_news_domain_model_news','{\"oldRecord\":{\"type\":\"1\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"type\":\"2\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"internalurl\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\",\\\"location\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"organizer\\\":\\\"\\\",\\\"price\\\":\\\"\\\",\\\"website\\\":\\\"\\\"}\"}}',0,'0400$92e065deb224176456878a0ae5415651:f3f39c24ca39d00c02ecd29ec2ad4225'),(34,1749211058,2,'BE',2,0,4,'tx_news_domain_model_news','{\"oldRecord\":{\"type\":\"2\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"internalurl\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\",\\\"location\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"organizer\\\":\\\"\\\",\\\"price\\\":\\\"\\\",\\\"website\\\":\\\"\\\"}\"},\"newRecord\":{\"type\":\"event\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"externalurl\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\",\\\"location\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"organizer\\\":\\\"\\\",\\\"price\\\":\\\"\\\",\\\"website\\\":\\\"\\\"}\"}}',0,'0400$e33004a36e5ef0ac9bd068c5e5ee3b89:f3f39c24ca39d00c02ecd29ec2ad4225'),(35,1749211074,4,'BE',2,0,4,'tx_news_domain_model_news',NULL,0,'0400$8a9d36ce0307da6d01dc9d201449777f:f3f39c24ca39d00c02ecd29ec2ad4225'),(36,1749211083,1,'BE',2,0,5,'tx_news_domain_model_news','{\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"hidden\":\"0\",\"istopnews\":\"0\",\"editlock\":\"0\",\"path_segment\":\"default-bd5f84e98a2550c8184dc65509bfc5c4\",\"date\":0,\"sitemap_priority\":\"0.5\",\"pid\":3,\"type\":\"event\",\"teaser\":\"\",\"datetime\":1749211079,\"archive\":0,\"bodytext\":\"\",\"organizer\":\"\",\"price\":\"\",\"categories\":\"0\",\"related\":\"0\",\"tags\":\"0\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sys_language_uid\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"crdate\":1749211083,\"t3ver_stage\":0,\"tstamp\":1749211083,\"uid\":5}',0,'0400$9389f7337055da4dc396942b51e09745:bc83755a03cca2ca5c8daa03e9d6e32e'),(37,1749211107,2,'BE',2,0,5,'tx_news_domain_model_news','{\"oldRecord\":{\"title\":\"\",\"teaser\":\"\",\"bodytext\":\"\",\"location\":\"\",\"organizer\":\"\",\"price\":\"\",\"website\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"title\":\"asdaa\",\"teaser\":\"evffg\",\"bodytext\":\"<p>vetbhtjr<\\/p>\",\"location\":\"aaaaa\",\"organizer\":\"asfasf\",\"price\":\"asfa\",\"website\":\"https:\\/\\/t3planet.de\\/en\\/blog\\/add-css-js-typo3\\/\",\"l10n_diffsource\":\"{\\\"title\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"location\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"organizer\\\":\\\"\\\",\\\"price\\\":\\\"\\\",\\\"website\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\"}\"}}',0,'0400$14545053b4dc199b7ee4e3d83b9797b1:bc83755a03cca2ca5c8daa03e9d6e32e'),(38,1749211285,4,'BE',2,0,5,'tx_news_domain_model_news',NULL,0,'0400$40fedc9b0f95cd06dbc601a28ea5109f:bc83755a03cca2ca5c8daa03e9d6e32e');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) COLLATE utf8mb4_general_ci NOT NULL,
  `status` smallint unsigned NOT NULL DEFAULT '0',
  `created` int unsigned NOT NULL,
  `changed` int unsigned NOT NULL,
  `type` varchar(32) COLLATE utf8mb4_general_ci NOT NULL,
  `scope` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `request_time` bigint unsigned NOT NULL,
  `meta` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `details` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `summary` varchar(40) COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `userid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `record_table` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `record_uid` int NOT NULL DEFAULT '0',
  `record_pid` int NOT NULL DEFAULT '0',
  `username` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `feuserid` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES (82,2,1749212748,'tx_news_domain_model_news',3,0,'aleksandar',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `userid` int unsigned NOT NULL DEFAULT '0',
  `action` smallint unsigned NOT NULL DEFAULT '0',
  `recuid` int unsigned NOT NULL DEFAULT '0',
  `tablename` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `recpid` int NOT NULL DEFAULT '0',
  `error` smallint unsigned NOT NULL DEFAULT '0',
  `details` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `type` smallint unsigned NOT NULL DEFAULT '0',
  `channel` varchar(20) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `details_nr` smallint NOT NULL DEFAULT '0',
  `IP` varchar(39) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `log_data` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `event_pid` int NOT NULL DEFAULT '-1',
  `workspace` int NOT NULL DEFAULT '0',
  `request_id` varchar(13) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT '0',
  `component` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `level` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'info',
  `message` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `data` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES (1,1748595883,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,-99,'',0,'','info',NULL,NULL),(2,1748595902,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,-99,'',0,'','info',NULL,NULL),(3,1748596226,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,-99,'',0,'','info',NULL,NULL),(4,1748596243,2,2,1,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"sys_template\",\"uid\":1,\"history\":\"1\"}',1,0,'',0,'','info',NULL,NULL),(5,1748596269,2,2,1,'sys_template',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"sys_template\",\"uid\":1,\"history\":\"2\"}',1,0,'',0,'','info',NULL,NULL),(7,1748596322,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(12,1748596827,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(13,1749196709,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,-99,'',0,'','info',NULL,NULL),(14,1749196743,2,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),(15,1749196748,2,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),(16,1749196762,2,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL),(17,1749196770,2,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":3,\"history\":\"6\"}',2,0,'',0,'','info',NULL,NULL),(18,1749196793,2,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),(19,1749196797,2,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),(20,1749196802,2,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),(21,1749196811,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"history\":\"10\"}',1,0,'',0,'','info',NULL,NULL),(22,1749196822,2,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":4,\"history\":\"11\"}',1,0,'',0,'','info',NULL,NULL),(23,1749196829,2,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":5,\"history\":\"12\"}',1,0,'',0,'','info',NULL,NULL),(24,1749196836,2,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"pages\",\"uid\":6,\"history\":\"13\"}',1,0,'',0,'','info',NULL,NULL),(25,1749196931,2,1,1,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"pid\":6}',6,0,'',0,'','info',NULL,NULL),(26,1749196969,2,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":2,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),(27,1749197032,2,1,1,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(28,1749197079,2,1,2,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(29,1749197110,2,1,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(30,1749197122,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"19\"}',6,0,'',0,'','info',NULL,NULL),(31,1749197128,2,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"20\"}',4,0,'',0,'','info',NULL,NULL),(32,1749197336,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(33,1749197517,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(34,1749197855,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(35,1749197922,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(36,1749198166,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(37,1749198238,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(38,1749199576,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(39,1749199587,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(40,1749199593,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(41,1749199596,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(42,1749199601,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(43,1749199635,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(44,1749199663,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(45,1749199760,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"21\"}',3,0,'',0,'','info',NULL,NULL),(46,1749199764,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"22\"}',3,0,'',0,'','info',NULL,NULL),(47,1749199770,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"23\"}',3,0,'',0,'','info',NULL,NULL),(48,1749199823,2,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":3,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),(49,1749199831,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(50,1749201291,2,1,1,'sys_category',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"sys_category\",\"uid\":1,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(51,1749201354,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"26\"}',3,0,'',0,'','info',NULL,NULL),(52,1749201734,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(53,1749202031,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(58,1749202135,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(59,1749202220,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(60,1749202332,2,1,0,'',0,0,'Personal settings changed',254,'default',0,'172.18.0.6','',-1,0,'',0,'','info',NULL,NULL),(61,1749202332,2,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"be_users\",\"uid\":2,\"history\":\"27\"}',0,0,'',0,'','info',NULL,NULL),(66,1749202368,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(80,1749202408,2,2,3,'tx_news_domain_model_news',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',0,'172.18.0.6','{\"reason\":\"An exception occurred while executing a query: Unknown column \'location\' in \'field list\'\",\"table\":\"tx_news_domain_model_news\",\"uid\":3}',-1,0,'',0,'','info',NULL,NULL),(81,1749202448,2,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"be_users\",\"uid\":2,\"history\":\"28\"}',0,0,'',0,'','info',NULL,NULL),(82,1749202538,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"29\"}',6,0,'',0,'','info',NULL,NULL),(83,1749202542,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(84,1749208765,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(85,1749209454,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(86,1749209503,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"30\"}',3,0,'',0,'','info',NULL,NULL),(87,1749209688,2,2,3,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"31\"}',3,0,'',0,'','info',NULL,NULL),(88,1749209689,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(89,1749211010,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(90,1749211047,2,1,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(91,1749211050,2,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":\"33\"}',3,0,'',0,'','info',NULL,NULL),(92,1749211058,2,2,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"history\":\"34\"}',3,0,'',0,'','info',NULL,NULL),(93,1749211074,2,3,4,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(94,1749211078,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(95,1749211083,2,1,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(96,1749211107,2,2,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"history\":\"37\"}',3,0,'',0,'','info',NULL,NULL),(97,1749211145,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(98,1749211282,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(99,1749211285,2,3,5,'tx_news_domain_model_news',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.6','{\"table\":\"tx_news_domain_model_news\",\"uid\":5,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),(100,1749211400,2,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.6','[\"aleksandar\"]',-1,0,'',0,'','info',NULL,NULL),(101,1749211671,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(102,1749211763,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(103,1749211823,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(104,1749212092,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(105,1749212390,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(106,1749212647,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(107,1749212688,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(108,1749212905,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(109,1749212930,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),(110,1749213129,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"aleksandar\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `headers` longtext COLLATE utf8mb4_general_ci NOT NULL,
  `queue_name` varchar(190) COLLATE utf8mb4_general_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `content` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `cruser` int unsigned NOT NULL DEFAULT '0',
  `category` int unsigned NOT NULL DEFAULT '0',
  `subject` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `message` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `personal` smallint unsigned NOT NULL DEFAULT '0',
  `position` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `updatedon` int unsigned NOT NULL DEFAULT '0',
  `createdon` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `disabled` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `impersonate_user` int unsigned NOT NULL DEFAULT '0',
  `storage_pid` int unsigned NOT NULL DEFAULT '0',
  `reaction_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `identifier` varchar(36) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `secret` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `table_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `fields` json DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `recuid` int unsigned NOT NULL DEFAULT '0',
  `field` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '2147483647',
  `t3ver_state` int unsigned NOT NULL DEFAULT '0',
  `flexpointer` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `softref_key` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `softref_id` varchar(40) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `sorting` int NOT NULL DEFAULT '0',
  `workspace` int unsigned NOT NULL DEFAULT '0',
  `ref_table` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ref_uid` int NOT NULL DEFAULT '0',
  `ref_field` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ref_hidden` smallint unsigned NOT NULL DEFAULT '0',
  `ref_starttime` int unsigned NOT NULL DEFAULT '0',
  `ref_endtime` int unsigned NOT NULL DEFAULT '2147483647',
  `ref_t3ver_state` int unsigned NOT NULL DEFAULT '0',
  `ref_sorting` int NOT NULL DEFAULT '0',
  `ref_string` varchar(1024) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES ('4849155964f9c16521aa52ae9b860ebe','tt_content',1,'pi_flexform',0,0,2147483647,0,'additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',5,'',0,0,2147483647,0,0,''),('75b459c6af5f2ba845e401dd7c71363b','tt_content',2,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),('b8a5c91d7ce286fde55697e89f592ce5','tt_content',1,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.startingpoint/vDEF/','','',0,0,'pages',3,'',0,0,2147483647,0,0,''),('b997a44b54d602ded3ae3ff76642a423','tx_news_domain_model_news',2,'related_from',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'',0,0,2147483647,0,1,''),('d391eaf782839a2327c293561d1b0bc6','sys_category',1,'items',0,0,2147483647,0,'','','',0,0,'tx_news_domain_model_news',3,'categories',0,0,2147483647,0,1,''),('e8c25120f3e1ff259e63f8d0cc653404','be_users',2,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'aleksandar.jovancic@hotbytes.de');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `entry_key` varchar(128) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES (1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration',_binary 'i:1;'),(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration',_binary 'i:1;'),(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration',_binary 'i:1;'),(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate',_binary 'i:1;'),(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration',_binary 'i:1;'),(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage',_binary 'i:1;'),(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration',_binary 'i:1;'),(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration',_binary 'i:1;'),(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate',_binary 'i:1;'),(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration',_binary 'i:1;'),(11,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate',_binary 'i:1;'),(12,'installUpdate','GeorgRinger\\News\\Updates\\NewsSlugUpdater',_binary 'i:1;'),(13,'installUpdate','GeorgRinger\\News\\Updates\\PluginPermissionUpdater',_binary 'i:1;'),(14,'installUpdate','GeorgRinger\\News\\Updates\\PluginUpdater',_binary 'i:1;'),(15,'installUpdate','GeorgRinger\\News\\Updates\\PopulateCategorySlugs',_binary 'i:1;'),(16,'installUpdate','GeorgRinger\\News\\Updates\\PopulateTagSlugs',_binary 'i:1;'),(17,'installUpdate','GeorgRinger\\News\\Updates\\RelatedLinkIntegerDefault',_binary 'i:1;'),(18,'installUpdate','GeorgRinger\\News\\Updates\\TitleFieldDefault',_binary 'i:1;'),(19,'installUpdateRows','rowUpdatersDone',_binary 'a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),(20,'extensionDataImport','typo3/cms-core/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(21,'extensionDataImport','typo3/cms-extbase/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(22,'extensionDataImport','typo3/cms-fluid/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(23,'extensionDataImport','typo3/cms-install/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(24,'extensionDataImport','typo3/cms-backend/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(25,'extensionDataImport','typo3/cms-frontend/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(26,'extensionDataImport','typo3/cms-dashboard/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(27,'extensionDataImport','typo3/cms-fluid-styled-content/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(28,'extensionDataImport','typo3/cms-filelist/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(29,'extensionDataImport','typo3/cms-impexp/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(30,'extensionDataImport','typo3/cms-form/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(31,'extensionDataImport','typo3/cms-seo/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(32,'extensionDataImport','typo3/cms-setup/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(33,'extensionDataImport','typo3/cms-rte-ckeditor/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(34,'extensionDataImport','typo3/cms-sys-note/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(35,'extensionDataImport','typo3/cms-belog/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(36,'extensionDataImport','typo3/cms-beuser/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(37,'extensionDataImport','typo3/cms-extensionmanager/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(38,'extensionDataImport','typo3/cms-felogin/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(39,'extensionDataImport','typo3/cms-info/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(40,'extensionDataImport','typo3/cms-reactions/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(41,'extensionDataImport','typo3/cms-recycler/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(42,'extensionDataImport','typo3/cms-tstemplate/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(43,'extensionDataImport','typo3/cms-viewpage/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(44,'extensionDataImport','typo3/cms-webhooks/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(45,'extensionDataImport','georgringer/news/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(46,'extensionDataImport','sashex/site_package/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(47,'extensionDataImport','helhum/typo3-console/ext_tables_static+adt.sql',_binary 's:0:\"\";'),(48,'core','formProtectionSessionToken:2',_binary 's:64:\"a746ef2036bb33bc2c55c0153370ecbc4ec17e349c45e88873dec3de3fa54493\";'),(49,'languagePacks','de-site_package',_binary 'i:1749202312;'),(50,'languagePacks','de',_binary 'i:1749202312;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `tx_impexp_origuid` int NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `root` smallint unsigned NOT NULL DEFAULT '0',
  `clear` smallint unsigned NOT NULL DEFAULT '0',
  `constants` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `include_static_file` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `basedOn` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `includeStaticAfterBasedOn` smallint unsigned NOT NULL DEFAULT '0',
  `config` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `static_file_mode` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES (1,1,1748596269,1748595958,0,0,0,0,0,'This is an Empty Site Package TypoScript record.\r\n\r\nFor each website you need a TypoScript record on the main page of your website (on the top level). For better maintenance all TypoScript should be extracted into external files via @import \'EXT:site_myproject/Configuration/TypoScript/setup.typoscript\'',0,'Main TypoScript Rendering',1,3,'','EXT:fluid_styled_content/Configuration/TypoScript/,EXT:fluid_styled_content/Configuration/TypoScript/Styling/,EXT:news/Configuration/TypoScript,EXT:site_package/Configuration/TypoScript,EXT:news/Configuration/TypoScript/SeoSitemap',NULL,0,'',0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `updatedon` int unsigned NOT NULL DEFAULT '0',
  `createdon` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `disabled` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `webhook_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `identifier` varchar(36) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `secret` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `url` text COLLATE utf8mb4_general_ci NOT NULL DEFAULT (_utf8mb3''),
  `method` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `verify_ssl` smallint unsigned NOT NULL DEFAULT '1',
  `additional_headers` json DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `fe_group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `rowDescription` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `editlock` smallint unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l18n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_source` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l18n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `frame_class` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'default',
  `colPos` int unsigned NOT NULL DEFAULT '0',
  `table_caption` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tx_impexp_origuid` int NOT NULL DEFAULT '0',
  `tx_news_related_news` int NOT NULL DEFAULT '0',
  `CType` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `categories` int unsigned NOT NULL DEFAULT '0',
  `layout` int unsigned NOT NULL DEFAULT '0',
  `space_before_class` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `space_after_class` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `date` bigint NOT NULL DEFAULT '0',
  `header` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `header_layout` int unsigned NOT NULL DEFAULT '0',
  `header_position` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `header_link` text COLLATE utf8mb4_general_ci NOT NULL DEFAULT (_utf8mb3''),
  `subheader` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `bodytext` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `image` int unsigned NOT NULL DEFAULT '0',
  `assets` int unsigned NOT NULL DEFAULT '0',
  `imagewidth` int unsigned NOT NULL DEFAULT '0',
  `imageheight` int unsigned NOT NULL DEFAULT '0',
  `imageorient` int unsigned NOT NULL DEFAULT '0',
  `imageborder` smallint unsigned NOT NULL DEFAULT '0',
  `image_zoom` smallint unsigned NOT NULL DEFAULT '0',
  `imagecols` int unsigned NOT NULL DEFAULT '0',
  `pages` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `recursive` int unsigned NOT NULL DEFAULT '0',
  `list_type` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `media` int unsigned NOT NULL DEFAULT '0',
  `records` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `sectionIndex` smallint unsigned NOT NULL DEFAULT '1',
  `linkToTop` smallint unsigned NOT NULL DEFAULT '0',
  `pi_flexform` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `selected_categories` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `category_field` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `bullets_type` int unsigned NOT NULL DEFAULT '0',
  `cols` int unsigned NOT NULL DEFAULT '0',
  `table_class` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `table_delimiter` int unsigned NOT NULL DEFAULT '0',
  `table_enclosure` int unsigned NOT NULL DEFAULT '0',
  `table_header_position` int unsigned NOT NULL DEFAULT '0',
  `table_tfoot` smallint unsigned NOT NULL DEFAULT '0',
  `file_collections` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `filelink_size` smallint unsigned NOT NULL DEFAULT '0',
  `filelink_sorting` varchar(64) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `target` varchar(30) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `uploads_description` smallint unsigned NOT NULL DEFAULT '0',
  `uploads_type` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `index_newscontent` (`tx_news_related_news`),
  KEY `translation_source` (`l10n_source`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES (1,6,1749202538,1749196931,0,0,0,0,'',256,'',0,0,0,0,NULL,_binary '{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"categories\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'default',0,NULL,0,0,'news_newsliststicky',0,0,'','',0,'Latest News',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\">crdate</value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\">desc</value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\">datetime</value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">5</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),(2,4,1749197128,1749196969,0,0,0,0,'',256,'',0,0,0,0,NULL,_binary '{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"categories\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'default',0,NULL,0,0,'news_newsliststicky',0,0,'','',0,'List of News',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\">3</value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),(3,5,1749199823,1749199823,0,0,0,0,'',256,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,0,'news_newsdetail',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.singleNews\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `extension_key` varchar(60) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `remote` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'ter',
  `version` varchar(15) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `alldownloadcounter` int unsigned NOT NULL DEFAULT '0',
  `downloadcounter` int unsigned NOT NULL DEFAULT '0',
  `title` varchar(150) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `author_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `author_email` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `ownerusername` varchar(50) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `md5hash` varchar(35) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `authorcompany` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `integer_version` int NOT NULL DEFAULT '0',
  `lastreviewedversion` int NOT NULL DEFAULT '0',
  `documentation_link` varchar(2048) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `distribution_image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `distribution_welcome_image` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `state` int unsigned NOT NULL DEFAULT '0',
  `category` int unsigned NOT NULL DEFAULT '0',
  `last_updated` bigint NOT NULL DEFAULT '0',
  `update_comment` longtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `current_version` smallint unsigned NOT NULL DEFAULT '0',
  `review_state` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `public` smallint NOT NULL DEFAULT '0',
  `item_uid` int NOT NULL DEFAULT '0',
  `user_uid` int unsigned NOT NULL DEFAULT '0',
  `preset_data` blob DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_link` (
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_source` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `t3_origuid` int unsigned NOT NULL DEFAULT '0',
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `parent` int NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `uri` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news` (
  `notes` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `starttime` int unsigned NOT NULL DEFAULT '0',
  `endtime` int unsigned NOT NULL DEFAULT '0',
  `fe_group` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `editlock` smallint unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_source` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `t3_origuid` int unsigned NOT NULL DEFAULT '0',
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `teaser` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `bodytext` mediumtext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `datetime` bigint NOT NULL DEFAULT '0',
  `archive` bigint NOT NULL DEFAULT '0',
  `author` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `author_email` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `categories` int NOT NULL DEFAULT '0',
  `related` int NOT NULL DEFAULT '0',
  `related_from` int NOT NULL DEFAULT '0',
  `related_files` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `fal_related_files` int unsigned DEFAULT '0',
  `related_links` int NOT NULL DEFAULT '0',
  `type` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '0',
  `keywords` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `tags` int NOT NULL DEFAULT '0',
  `media` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `fal_media` int unsigned DEFAULT '0',
  `internalurl` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `externalurl` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `istopnews` int NOT NULL DEFAULT '0',
  `content_elements` int NOT NULL DEFAULT '0',
  `path_segment` varchar(2048) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `alternative_title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `sitemap_changefreq` varchar(10) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT '0.5',
  `import_id` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `import_source` varchar(100) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `location` varchar(128) COLLATE utf8mb4_general_ci DEFAULT '',
  `organizer` varchar(128) COLLATE utf8mb4_general_ci DEFAULT '',
  `date` int DEFAULT '0',
  `price` varchar(64) COLLATE utf8mb4_general_ci DEFAULT '',
  `website` varchar(255) COLLATE utf8mb4_general_ci DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES ('',1,3,1749197032,1749197032,0,0,0,0,'',0,0,0,0,NULL,0,'',0,0,0,0,0,'Python sucks','This is why python sucks','<h2>Why Python Sucks (But Everyone’s Too Polite to Say It)</h2>\r\n<ul><li><strong>“Readability counts”</strong> — unless you\'re reading <i>someone else\'s</i> Python code, in which case it\'s 2,000 lines of unexplained magic using libraries you\'ve never heard of, written with indentation so aggressive it could start a war.</li><li><strong>Whitespace is syntax.</strong> One misplaced space and your whole script collapses like a poorly constructed IKEA shelf. Want tabs and spaces together? Python says: <i>\"Go to jail.\"</i></li><li><strong>Dynamic typing?</strong> Feels great until your function that was returning a string suddenly returns a list, then a dictionary, then a goat. And you don’t find out until runtime — surprise!</li><li><strong>It’s slow.</strong> Python is slower than a snail on melatonin. Want to process a million rows of data? Better make a coffee. Or two. Maybe go on a weekend retreat.</li><li><strong>Global Interpreter Lock (GIL).</strong> Ah yes, multithreading — but only one thread can run at a time. You can import threading, but it’s just cosplay. True parallelism? Not here.</li><li><strong>Error messages?</strong> Sometimes helpful. Other times: <i>\"NoneType object has no attribute \'wiggle’.”</i> Oh thanks Python, that really narrows it down.</li><li><strong>Duck typing.</strong> “If it quacks like a duck…” — but sometimes it explodes like a grenade, and Python just shrugs and calls it “flexible.”</li><li><strong>Packaging hell.</strong> Pip, pipenv, poetry, virtualenv, conda — it\'s like five competing religions fighting over the same package manager. And none of them work exactly right.</li><li><strong>Version anxiety.</strong> Python 2 or 3? Hope you picked right — because your dependencies sure didn’t. Welcome to the kingdom of ImportError.</li><li><strong>Lambda expressions?</strong> Cool idea, but Python neutered them so hard they can barely hold a one-liner. You want an inline function? Good luck. You want logic in that function? Too bad.</li></ul>\r\n<h2>Final Thoughts</h2>\r\n<p>Python is the friendliest knife in the drawer. It looks cute, it feels nice, and then one day it slices your leg off because you called .strip() on None.</p>\r\n<p>It’s fun for beginners, great for quick scripts, and unbeatable for data science. But when it’s time to scale, optimize, or maintain — well, hope you like duct tape and prayer.</p>\r\n<p>Python isn’t the worst tool in the shed. But it sure is the one with the least safety warnings and the highest accidental amputations.</p>',1749196984,0,'','',0,0,0,NULL,0,0,'0','','',0,NULL,0,NULL,NULL,0,0,'python-sucks','','',0.5,'','','','',0,'',''),('',2,3,1749197079,1749197079,0,0,0,0,'',0,0,0,0,NULL,0,'',0,0,0,0,0,'C Plus Plus is the best','why cpp is the best language ever','<h2>Why C++ is the Best (Totally Objective, Absolutely Serious)</h2>\r\n<ul><li><strong>Do you enjoy pain?</strong> Excellent. C++ isn’t just a programming language; it’s a rite of passage. Segmentation faults, undefined behavior, and error messages that read like ancient curses — what’s not to love?</li><li><strong>Memory management?</strong> Forget garbage collectors. In C++, <i>you</i> are the garbage collector. Allocate memory with new, deallocate it with delete, forget one? Enjoy the memory leak. It builds character.</li><li><strong>Syntax?</strong> It’s elegant — in the same way an old cathedral is elegant: intricate, mysterious, and maybe haunted. One line of C++ can either sort a list or summon a compiler demon.</li><li><strong>Templates?</strong> Want code that looks like math homework from the fourth dimension? Want to write something once and break in ten ways on ten compilers? Templates. Beautiful, monstrous templates.</li><li><strong>Multi-paradigm power.</strong> C++ lets you write procedural code, object-oriented code, functional code, and existential horror — all in the same file. Sometimes in the same function.</li><li><strong>The community?</strong> Gritty, battle-hardened, and fluent in cryptic compiler errors. We don’t run from danger — we override operator&lt;&lt; and run straight into it.</li><li><strong>Cross-platform and timeless.</strong> Whether you\'re writing a game engine, a high-frequency trading bot, or firmware for a microwave, C++ has been there, done that, and probably wrote the standard for it.</li><li><strong>It just works.</strong> After 17 compiler flags, a Makefile incantation, and sacrificing a Java developer to the linker, your program will compile. Maybe. If the stars align.</li></ul>\r\n<h2>Final Thoughts</h2>\r\n<p>C++ isn’t just a tool — it’s a test of will. It’s not the easiest, not the friendliest, but it <i>is</i> the one that makes you feel like you’ve earned it. If you can write solid C++, everything else feels like child’s play.</p>\r\n<p>Welcome to C++. No safety rails. No excuses. Just you, the code, and the void.</p>',1749197039,0,'','',0,0,0,NULL,0,0,'0','','',0,NULL,0,NULL,NULL,0,0,'c-plus-plus-is-the-best','','',0.5,'','','','',0,'',''),('',3,3,1749209688,1749197110,0,0,0,0,'',0,0,0,0,NULL,0,_binary '{\"type\":\"\",\"istopnews\":\"\",\"title\":\"\",\"path_segment\":\"\",\"teaser\":\"\",\"datetime\":\"\",\"archive\":\"\",\"bodytext\":\"\",\"location\":\"\",\"date\":\"\",\"organizer\":\"\",\"price\":\"\",\"website\":\"\",\"content_elements\":\"\",\"fal_media\":\"\",\"fal_related_files\":\"\",\"categories\":\"\",\"related\":\"\",\"related_links\":\"\",\"tags\":\"\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"notes\":\"\"}',0,0,0,0,0,'Java sucks, delete it from the world','worst ever language made','<h2>Why Java Sucks (But Only a Little. Maybe.)</h2>\r\n<ul><li><strong>\"Write once, run anywhere\"?</strong> More like <i>\"Write once, debug everywhere.\"</i> Java promised us platform independence. What we got was a JVM that behaves differently on every machine and a jar file that only runs if Jupiter’s moons are in retrograde.</li><li><strong>Boilerplate?</strong> Oh, Java loves it. Want to print “Hello, World”? That’ll be one class, one method, a public static void main, some curly braces, and your soul.</li><li><strong>Everything is a class.</strong> Need a simple script? Too bad. Everything must live in a class. Even if you’re just trying to add two numbers, Java’s dragging you into OOP like a clingy ex.</li><li><strong>Verbose much?</strong> In Java, what takes one line in Python takes ten. Need a list of strings? List&lt;String&gt; myList = new ArrayList&lt;String&gt;(); — and that’s before you even add anything to it.</li><li><strong>Garbage collected?</strong> Yes — but not when you want it to be. And when the GC <i>does</i> show up, it might freeze your app just long enough for your users to uninstall it.</li><li><strong>Checked exceptions.</strong> Because what every developer wants is to be <i>forced</i> to handle errors they can’t possibly recover from. Your code will look like a sea of try/catch blocks duct-taped together just to make the compiler happy.</li><li><strong>JavaFX and GUI development?</strong> If you like dragging your eyeballs over XML files and clicking 400 times to get one button to align, Java’s got you. It’s like building a house by whispering instructions to a brick.</li><li><strong>The ecosystem.</strong> Want to use a modern framework? Enjoy 17 Maven dependencies, a build process that summons half the internet, and an IDE that cries every time you update one version.</li><li><strong>JVM startup time.</strong> Sure, the code runs eventually. But first it warms up. Slowly. Like a 1998 Toyota Corolla in Siberia.</li></ul>\r\n<h2>Closing Arguments</h2>\r\n<p>Java isn’t evil — it’s just the corporate intern that won’t stop talking about how \"enterprise\" it is. It’ll make you write getters, setters, abstract factory beans, and service locators just to say <i>\"hello.\"</i></p>\r\n<p>It’s not the worst language — but it sure tries to be the most annoyingly bureaucratic. If you enjoy coding with a straightjacket and a 500-page instruction manual, Java’s waiting.</p>\r\n<p>Otherwise? Run.</p>\r\n<p>Unless the garbage collector already paused you.</p>',1749197091,0,'','',1,1,0,NULL,0,0,'0','','',0,NULL,0,NULL,NULL,0,0,'java-sucks-delete-it-from-the-world','','',0.5,'','','gundelsheim','aaa',1751023860,'100','https://www.youtube.com/watch?v=QZPvUgdIQ38'),('',4,3,1749211074,1749211047,1,0,0,0,'',0,0,0,0,NULL,0,_binary '{\"type\":\"\",\"istopnews\":\"\",\"title\":\"\",\"path_segment\":\"\",\"teaser\":\"\",\"externalurl\":\"\",\"datetime\":\"\",\"archive\":\"\",\"fal_media\":\"\",\"fal_related_files\":\"\",\"categories\":\"\",\"related\":\"\",\"related_links\":\"\",\"tags\":\"\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"notes\":\"\",\"location\":\"\",\"date\":\"\",\"organizer\":\"\",\"price\":\"\",\"website\":\"\"}',0,0,0,0,0,'','','',1749211023,0,'','',0,0,0,NULL,0,0,'event','','',0,NULL,0,NULL,NULL,0,0,'default-8fc87da7fc9a18fb53a05f705bb3dfaa','','',0.5,'','','','',0,'',''),('',5,3,1749211285,1749211083,1,0,0,0,'',0,0,0,0,NULL,0,_binary '{\"title\":\"\",\"teaser\":\"\",\"bodytext\":\"\",\"location\":\"\",\"date\":\"\",\"organizer\":\"\",\"price\":\"\",\"website\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\"}',0,0,0,0,0,'asdaa','evffg','<p>vetbhtjr</p>',1749211079,0,'','',0,0,0,NULL,0,0,'event','','',0,NULL,0,NULL,NULL,0,0,'default-bd5f84e98a2550c8184dc65509bfc5c4','','',0.5,'','','aaaaa','asfasf',0,'asfa','https://t3planet.de/en/blog/add-css-js-typo3/');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int NOT NULL DEFAULT '0',
  `uid_foreign` int NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `sorting_foreign` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news_related_mm` VALUES (2,3,0,1);
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int NOT NULL DEFAULT '0',
  `uid_foreign` int NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  `sorting_foreign` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_ttcontent_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_ttcontent_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_news_ttcontent_mm` (
  `uid_local` int NOT NULL DEFAULT '0',
  `uid_foreign` int NOT NULL DEFAULT '0',
  `sorting` int NOT NULL DEFAULT '0',
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_ttcontent_mm`
--

LOCK TABLES `tx_news_domain_model_news_ttcontent_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `notes` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `uid` int unsigned NOT NULL AUTO_INCREMENT,
  `pid` int unsigned NOT NULL DEFAULT '0',
  `tstamp` int unsigned NOT NULL DEFAULT '0',
  `crdate` int unsigned NOT NULL DEFAULT '0',
  `deleted` smallint unsigned NOT NULL DEFAULT '0',
  `hidden` smallint unsigned NOT NULL DEFAULT '0',
  `sys_language_uid` int NOT NULL DEFAULT '0',
  `l10n_parent` int unsigned NOT NULL DEFAULT '0',
  `l10n_source` int unsigned NOT NULL DEFAULT '0',
  `l10n_state` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `l10n_diffsource` mediumblob DEFAULT (NULL),
  `t3ver_oid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_wsid` int unsigned NOT NULL DEFAULT '0',
  `t3ver_state` smallint NOT NULL DEFAULT '0',
  `t3ver_stage` int NOT NULL DEFAULT '0',
  `title` tinytext COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `slug` varchar(2048) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `seo_description` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  `seo_headline` varchar(255) COLLATE utf8mb4_general_ci NOT NULL DEFAULT '',
  `seo_text` text COLLATE utf8mb4_general_ci DEFAULT (NULL),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-06 14:38:48
